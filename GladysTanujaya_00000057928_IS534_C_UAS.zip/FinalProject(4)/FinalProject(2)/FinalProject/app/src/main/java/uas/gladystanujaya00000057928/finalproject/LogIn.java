package uas.gladystanujaya00000057928.finalproject;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;


public class LogIn extends AppCompatActivity {
    
    private EditText username, password;
    private Button btn_login;
    private static String URL_LOGIN = "http://192.168.1.3/gonation/login.php";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log_in);

        username = findViewById(R.id.edtUsernameLogin);
        password = findViewById(R.id.edtPasswordLogin);
        btn_login = findViewById(R.id.btnLogIn);

        btn_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String mUsername = username.getText().toString().trim();
                String mPass = password.getText().toString().trim();

                if (!mUsername.isEmpty() || !mPass.isEmpty()) {
                    Login(mUsername, mPass);
                }else{
                    username.setError("Please insert your username");
                    password.setError("Please insert your password");
                }
            }

            private void Login(String username, String password) {
                StringRequest stringRequest = new StringRequest(Request.Method.POST, URL_LOGIN,
                        new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {
                                try{
                                    JSONObject jsonObject = new JSONObject(response);
                                    String success = jsonObject.getString("success");
                                    JSONArray jsonArray = jsonObject.getJSONArray("login");

                                    if(success.equals("1")){
                                        for(int i = 0; i <jsonArray.length(); i++){
                                            JSONObject object = jsonArray.getJSONObject(i);
                                            String username = object.getString("username").trim();
                                            Toast.makeText(LogIn.this, "Berhasil Login ke akun\n "+username, Toast.LENGTH_SHORT).show();
                                            Intent b =new Intent(getApplicationContext(), MainActivity.class);
                                            startActivity(b);
                                        }
                                    }else{
                                        Toast.makeText(LogIn.this, "Usernama atau Password Salah", Toast.LENGTH_SHORT).show();
                                        Intent c =new Intent(getApplicationContext(), LogIn.class);
                                        startActivity(c);
                                    }
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                    Toast.makeText(LogIn.this, "Error" + e.toString(), Toast.LENGTH_SHORT).show();
                                }
                            }
                        },
                        new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {
                                Toast.makeText(LogIn.this, "Error" + error.toString(), Toast.LENGTH_SHORT).show();
                            }
                        })
                {
                    @Override
                    protected Map<String, String> getParams() throws AuthFailureError {
                        Map<String,String>params = new HashMap<>();
                        params.put("username", username);
                        params.put("password", password);
                        return params;
                    }
                };

                RequestQueue requestQueue = Volley.newRequestQueue(LogIn.this);
                requestQueue.add(stringRequest);
            }
        });

        Button btnSignUp = (Button) findViewById(R.id.tombolsignup);
        btnSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(), SignUpActivity.class);
                startActivity(i);
            }
        });
    }
}
/*
Button btnLihatAkun = (Button) findViewById(R.id.btnLihatAkun);
        btnLihatAkun.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(), ProfileActivity.class);
                startActivity(i);
            }
        });
 */