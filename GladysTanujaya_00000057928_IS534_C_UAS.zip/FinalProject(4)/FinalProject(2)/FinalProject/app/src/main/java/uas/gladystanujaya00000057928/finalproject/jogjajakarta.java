package uas.gladystanujaya00000057928.finalproject;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class jogjajakarta extends AppCompatActivity {

    private EditText kelas, jmlpenumpang, jmlharga, metodepembayaran, tipekelastext, nama;
    private Button confirm, calculate;
    private Spinner spinJakartaSemarang;
    private String[] pilihKelas = {"- Pilih Kelas - ", "Executive", "Economy", "Buisness"};
    private Spinner spinMetodePembayaran;
    private String[] pilihmetodepembayaran = {"- Pilih Metode -", "Cash", "Credit"};
    String url_tambah_kereta = "http://192.168.1.3/gonation/addkereta.php";

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_jogjajakarta);

        spinMetodePembayaran = (Spinner) findViewById(R.id.spinMetodePembayaranJakJog);
        ArrayAdapter adapter1 = new ArrayAdapter(this, android.R.layout.simple_spinner_item, pilihmetodepembayaran);
        spinMetodePembayaran.setAdapter(adapter1);

        jmlpenumpang = (EditText) findViewById(R.id.edtPenumpangJakJog);
        jmlharga = (EditText) findViewById(R.id.edtHargajakJog);
        tipekelastext = (EditText) findViewById(R.id.tipeKelasJakJog);
        nama = (EditText)findViewById(R.id.edtNamaJakJog);

        Button btnExecutive = (Button) findViewById(R.id.btnExecutiveJakJog);
        btnExecutive.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int n1 = Integer.parseInt(jmlpenumpang.getText().toString());
                int n2 = 550000;
                int total = n1 * n2;
                jmlharga.setText("Rp"+String.valueOf(total)+",-");
                tipekelastext.setText("Executive");

            }
        });
        Button btnTipeEconomy = (Button) findViewById(R.id.btnTipeEconomyJakJog);
        btnTipeEconomy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int n1 = Integer.parseInt(jmlpenumpang.getText().toString());
                int n2 = 350000;
                int total = n1 * n2;
                jmlharga.setText("Rp"+String.valueOf(total)+",-");
                tipekelastext.setText("Economy");
            }
        });
        Button btnBisnis = (Button) findViewById(R.id.btnBisnisJakJog);
        btnBisnis.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int n1 = Integer.parseInt(jmlpenumpang.getText().toString());
                int n2 = 650000;
                int total = n1 * n2;
                jmlharga.setText("Rp"+String.valueOf(total)+",-");
                tipekelastext.setText("Buisness");
            }
        });
        Button btnKonfirmasi = (Button) findViewById(R.id.btnKonfirmasiJakSem);
        btnKonfirmasi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Confirm();
            }
        });
    }
    private void Confirm(){
        final String nama = this.nama.getText().toString().trim();
        final String jumlahpenumpang = this.jmlpenumpang.getText().toString().trim();
        final String tipekelas = this.tipekelastext.getText().toString().trim();
        final String total_harga = this.jmlharga.getText().toString().trim();
        final String metodepembayaran = this.spinMetodePembayaran.getSelectedItem().toString();
        final String tujuan = "Yogyakarta - Jakarta";
        //final String phone_number = this.phone_number.getText().toString().trim();

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url_tambah_kereta,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try{
                            JSONObject jsonObject = new JSONObject(response);
                            String success = jsonObject.getString("success");
                            if(success.equals("1")){
                                Toast.makeText(jogjajakarta.this,"Berhasil!", Toast.LENGTH_SHORT).show();
                                Intent a = new Intent(getApplicationContext(), PembayaranActivity.class);
                                startActivity(a);
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                            Toast.makeText(jogjajakarta.this,"Terjadi Kesalahan" + e.toString(), Toast.LENGTH_SHORT).show();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(jogjajakarta.this,"Error!" + error.toString(), Toast.LENGTH_SHORT).show();
                        Log.e("VOLLEY", error.toString());
                    }
                })
        {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("nama", nama);
                params.put("jumlah_penumpang", jumlahpenumpang);
                params.put("tipe_kelas", tipekelas);
                params.put("total_harga", total_harga);
                params.put("metode_pembayaran", metodepembayaran);
                params.put("tujuan", tujuan);
                //params.put("phone_number", phone_number);
                return params;
            }
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("Content-Type", "application/x-www-form-urlencoded");
                return params;
            }

        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }
}