package uas.gladystanujaya00000057928.finalproject;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatActivity;

public class KeretaActivity extends AppCompatActivity {
    private Spinner spinKeberangkatan;
    private String[] daftarStasiunKeberangkatan = {"- Pilih Stasiun Keberangkatan -", "Gambir", "Bandung",
    "Cirebon"};
    private String dataAsal;
    private Spinner spinTujuan;
    private String[] daftarStasiunTujuan = {"- Pilih Stasiun Tujuan -", "Semarang", "Surabaya", "Malang"};
    private Spinner spinClassKereta;
    private String[] daftarClassKereta = { "- Pilih Class Kereta -", "Ekonomi", "Eksekutif"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kereta);

        spinKeberangkatan = (Spinner) findViewById(R.id.spinKeberangkatan);
        ArrayAdapter adapter = new ArrayAdapter(this, android.R.layout.simple_spinner_item, daftarStasiunKeberangkatan);
        spinKeberangkatan.setAdapter(adapter);

        spinKeberangkatan.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                String spinnerKeberangkatan = adapterView.getItemAtPosition(i).toString();
                Button btnCariKereta = (Button) findViewById(R.id.btnCariKereta);
                btnCariKereta.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent u = new Intent(getApplicationContext(), PencarianKeretaActivity.class);
                        //Intent u = new Intent(getApplicationContext(), ResultActivity.class);
                        u.putExtra("SpinnerKeberangkatan", spinnerKeberangkatan);
                        startActivity(u);
                    }
                });
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        spinTujuan = (Spinner) findViewById(R.id.spinTujuan);
        ArrayAdapter adapter1 = new ArrayAdapter(this, android.R.layout.simple_spinner_item, daftarStasiunTujuan);
        spinTujuan.setAdapter(adapter1);

        spinTujuan.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int j, long l) {
                String spinnerTujuan = adapterView.getItemAtPosition(j).toString();
                Button btnCariKereta = (Button) findViewById(R.id.btnCariKereta);
                btnCariKereta.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent v = new Intent(getApplicationContext(), PencarianKeretaActivity.class);
                        v.putExtra("SpinnerTujuan", spinnerTujuan);
                        startActivity(v);
                    }
                });
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        spinClassKereta = (Spinner) findViewById(R.id.spinClassKereta);
        ArrayAdapter adapter2 = new ArrayAdapter(this, android.R.layout.simple_spinner_item, daftarClassKereta);
        spinClassKereta.setAdapter(adapter2);

        spinClassKereta.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int k, long l) {
                String spinnerClass = adapterView.getItemAtPosition(k).toString();
                Button btnCariKereta = (Button) findViewById(R.id.btnCariKereta);
                btnCariKereta.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent w = new Intent(getApplicationContext(), PencarianKeretaActivity.class);
                        final EditText editPenumpang = (EditText) findViewById(R.id.editTextPenumpang);
                        final EditText editTanggal = (EditText) findViewById(R.id.editTanggalBerangkat);
                        w.putExtra("SpinnerClass", spinnerClass);
                        w.putExtra("penumpang", editPenumpang.getText().toString());
                        w.putExtra("tanggal", editTanggal.getText().toString());
                        w.putExtra("harga1", 50000);
                        w.putExtra("harga2", 100000);
                        w.putExtra("harga3", 75000);
                        w.putExtra("harga4", 150000);
                        w.putExtra("harga5", 60000);
                        w.putExtra("harga6", 120000);
                        startActivity(w);
                    }
                });
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


    }
}