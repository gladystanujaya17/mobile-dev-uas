package uas.gladystanujaya00000057928.finalproject;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class HotelDetailActivity extends AppCompatActivity {

    private EditText tglmasuk, tglkeluar, jumlah, harga;
    String url_tambah_hotel = "http://192.168.1.3/gonation/addHotel.php";

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hotel_detail);

        tglmasuk = (EditText) findViewById(R.id.editTglMasuk);
        tglkeluar = (EditText) findViewById(R.id.editTglKeluar);
        jumlah = (EditText) findViewById(R.id.editJumlah2);
        harga = (EditText) findViewById(R.id.total);

        Button hitung = (Button) findViewById(R.id.hitung);
        hitung.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int jml = Integer.parseInt(jumlah.getText().toString());
                int hrg = 1000000;
                int total = jml * hrg;
                harga.setText("Rp"+String.valueOf(total)+",-");
            }
        });
        Button konfirm = (Button) findViewById(R.id.btnKonfirmasiPembayaran1);
        konfirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                masukdb();
            }
        });

    }
    public void masukdb(){
        final String masuk = this.tglmasuk.getText().toString().trim();
        final String keluar = this.tglkeluar.getText().toString().trim();
        final String jumlah = this.jumlah.getText().toString().trim();
        final String total = this.harga.getText().toString().trim();

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url_tambah_hotel,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try{
                            JSONObject jsonObject = new JSONObject(response);
                            String success = jsonObject.getString("success");
                            if(success.equals("1")){
                                Toast.makeText(HotelDetailActivity.this,"Berhasil!", Toast.LENGTH_SHORT).show();
                                Intent a = new Intent(getApplicationContext(), PembayaranActivity.class);
                                startActivity(a);
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                            Toast.makeText(HotelDetailActivity.this,"Terjadi Kesalahan" + e.toString(), Toast.LENGTH_SHORT).show();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(HotelDetailActivity.this,"Error!" + error.toString(), Toast.LENGTH_SHORT).show();
                        Log.e("VOLLEY", error.toString());
                    }
                })
        {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("tanggal_masuk", masuk);
                params.put("tanggal_keluar", keluar);
                params.put("harga", total);
                return params;
            }
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("Content-Type", "application/x-www-form-urlencoded");
                return params;
            }

        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

}