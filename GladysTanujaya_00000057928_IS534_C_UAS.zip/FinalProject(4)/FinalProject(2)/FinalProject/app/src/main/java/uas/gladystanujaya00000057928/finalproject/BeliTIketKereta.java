package uas.gladystanujaya00000057928.finalproject;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class BeliTIketKereta extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_beli_tiket_kereta);

        Button btnBeli = (Button) findViewById(R.id.btnJakartaSemarang);
        btnBeli.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent e = new Intent(getApplicationContext(), KeretaJakartaSemarang.class);
                startActivity(e);
            }
        });
        Button btnJakjog = (Button) findViewById(R.id.btnJakartaYogyakarta);
        btnJakjog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent f = new Intent(getApplicationContext(), jakartajogja.class);
                startActivity(f);
            }
        });
        Button btnJaksu = (Button) findViewById(R.id.btnJakartaSurabaya);
        btnJaksu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent g = new Intent(getApplicationContext(), jakartasurabaya.class);
                startActivity(g);
            }
        });
        Button btnsemjak = (Button) findViewById(R.id.btnSemarangJakarta);
        btnsemjak.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent h = new Intent(getApplicationContext(), semarangjakarta.class);
                startActivity(h);
            }
        });
        Button jogjak = (Button) findViewById(R.id.btnYogyakartaJakarta);
        jogjak.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), jogjajakarta.class);
                startActivity(i);
            }
        });
        Button surjak = (Button) findViewById(R.id.btnSurabayaJakarta);
        surjak.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent j = new Intent(getApplicationContext(), surabayajakarta.class);
                startActivity(j);
            }
        });
    }
}