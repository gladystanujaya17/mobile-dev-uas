package uas.gladystanujaya00000057928.finalproject;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class ProfileActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        Button button = (Button) findViewById(R.id.btnGantiProfile);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent d = new Intent(getApplicationContext(), AkunProfil.class);
                startActivity(d);
            }
        });

        Button btnAboutCompany = (Button) findViewById(R.id.btnAboutCompany);
        btnAboutCompany.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent d = new Intent(getApplicationContext(), FragmentAboutCompany.class);
                startActivity(d);
                //Lanjut ke About Company
            }
        });

        Button btnMaps = (Button) findViewById(R.id.btnMaps);
        btnMaps.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent d = new Intent(getApplicationContext(), MapsActivity.class);
                startActivity(d);
                //Lanjut ke Google Maps
            }
        });

        @SuppressLint("MissingInflatedId") Button logout = (Button) findViewById(R.id.logout);
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent k = new Intent(getApplicationContext(), LogIn.class);
                startActivity(k);
            }
        });



    }
}