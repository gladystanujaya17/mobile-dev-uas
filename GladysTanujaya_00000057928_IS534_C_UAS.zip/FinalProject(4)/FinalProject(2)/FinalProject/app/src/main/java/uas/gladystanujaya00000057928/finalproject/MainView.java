package uas.gladystanujaya00000057928.finalproject;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

import android.os.Bundle;

public class MainView extends AppCompatActivity {

    ViewPager mViewPager;
    //Ini biar ga error itu nama classnya jgn ViewPager, ganti nama lain

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        /*mViewPager = (ViewPager) findViewById(R.id.pager);
        mViewPager.setAdapter(new ViewPagerAdapter(
                getSupportFragmentManager()));
    }

    public class ViewPagerAdapter extends FragmentPagerAdapter {
        public ViewPagerAdapter(FragmentManager fm) {
            super(fm);
        }


        @Override
        public Fragment getItem(int position) {
            if (position == 0) {
                return new FragmentAboutCompany(); //Fragment Pertama
            } else {
                return new FragmentWebView();//Fragment Kedua
            }
        }

        @Override
        public int getCount() {
            return 2;
        }
    }
    */

    }
}