package uas.gladystanujaya00000057928.finalproject;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class KonfirmasiKereta extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_konfirmasi_kereta);

        TextView textConfirmBerangkat = (TextView) findViewById(R.id.textConfirmBerangkat);
        TextView textConfirmTujuan = (TextView) findViewById(R.id.textConfirmTujuan);
        TextView textConfirmClass = (TextView) findViewById(R.id.textConfirmClass);
        TextView textConfirmPenumpang = (TextView) findViewById(R.id.textConfirmPenumpang);
        TextView textConfirmTanggal = (TextView) findViewById(R.id.textConfirmTanggal);
        TextView textConfirmHarga = (TextView) findViewById(R.id.textConfirmHarga);

        Intent u = getIntent();
        String keberangkatan1 = u.getStringExtra("SpinnerKeberangkatan");

        Intent w = getIntent();
        String class1 = w.getStringExtra("SpinnerClass");
        String penumpang1 = w.getStringExtra("penumpang");
        String tanggal1 = w.getStringExtra("tanggal");

        textConfirmBerangkat.setText(keberangkatan1);
        textConfirmPenumpang.setText(penumpang1);
        textConfirmTanggal.setText(tanggal1);
        textConfirmClass.setText(class1);

        Button btnSubmitKereta = (Button) findViewById(R.id.btnSubmitKereta);
        btnSubmitKereta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(), PilihPembayaran.class);
                startActivity(i);
            }
        });
    }
}