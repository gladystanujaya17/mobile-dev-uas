package uas.gladystanujaya00000057928.finalproject;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class PencarianKeretaActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pencarian_kereta);

        TextView txtView12 = (TextView) findViewById(R.id.textView12);
        TextView txtView14 = (TextView) findViewById(R.id.textView14);
        TextView txtView17 = (TextView) findViewById(R.id.textView17);
        TextView txtView19 = (TextView) findViewById(R.id.textView19);
        TextView txtView22 = (TextView) findViewById(R.id.textView22);
        TextView txtView24 = (TextView) findViewById(R.id.textView24);
        TextView txtView15 = (TextView) findViewById(R.id.textView15);
        TextView txtView20 = (TextView) findViewById(R.id.textView20);
        TextView txtView25 = (TextView) findViewById(R.id.textView25);
        TextView txtView16 = (TextView) findViewById(R.id.textView16);
        TextView txtView21 = (TextView) findViewById(R.id.textView21);
        TextView txtView31 = (TextView) findViewById(R.id.textView31);

        Intent u = getIntent();
        String keberangkatan1 = u.getStringExtra("SpinnerKeberangkatan");
        txtView12.setText(keberangkatan1);
        txtView17.setText(keberangkatan1);
        txtView22.setText(keberangkatan1);


        Intent v = getIntent();
        String tujuan1 = v.getStringExtra("SpinnerTujuan");
        txtView14.setText(tujuan1);
        txtView19.setText(tujuan1);
        txtView24.setText(tujuan1);

        Intent w = getIntent();
        String class1 = w.getStringExtra("SpinnerClass");
        txtView15.setText(class1);
        txtView20.setText(class1);
        txtView25.setText(class1);

        Button btnPilih = (Button) findViewById(R.id.btnPilih);
        btnPilih.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(), KonfirmasiKereta.class);
                startActivity(i);
            }
        });

        Button btnPilih1 = (Button) findViewById(R.id.btnPilih1);
        btnPilih1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(), KonfirmasiKereta.class);
                startActivity(i);
            }
        });

        Button btnPilih2 = (Button) findViewById(R.id.btnPilih2);
        btnPilih2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(), KonfirmasiKereta.class);
                startActivity(i);
            }
        });
    }
}