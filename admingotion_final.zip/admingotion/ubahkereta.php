<?php
include "function.php";

$train_id = $_POST['id'];
$class_id = $_POST['class'];
$train_departure = $_POST['tglberangkat'];
$train_arrival = $_POST['tgltiba'];
$train_seats = $_POST['kursi'];
$train_price = $_POST['harga'];

$update = mysqli_query($conn, "UPDATE avail_train SET class_id='$class_id', 
                                                    train_departure='$train_departure',
                                                    train_arrival='$train_arrival',
                                                    train_seats='$train_seats',
                                                    train_price='$train_price'
                                                    WHERE train_id='$train_id'");

if ($update){
    echo "<script> alert {'Data berhasil diupdate'} </script>";
    header ("refresh:0;admin.php");
} else {
    echo "<script> alert {'Data tidak berhasil diupdate'} </script>";
    header ("refresh:0;admin.php");
}
?>