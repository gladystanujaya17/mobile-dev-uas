<?php
include "function.php";

$hotel_id = $_POST['id'];
$tanggal_masuk = $_POST['tglmasuk'];
$tanggal_keluar = $_POST['tglkeluar'];
$harga = $_POST['harga'];

$update = mysqli_query($conn, "UPDATE avail_hotel SET tanggal_masuk='$tanggal_masuk', 
                                                    tanggal_keluar='$tanggal_keluar',
                                                    harga='$harga'
                                                    WHERE hotel_id='$hotel_id'");

if ($update){
    echo "<script> alert {'Data berhasil diupdate'} </script>";
    header ("refresh:0;adminhotel.php");
} else {
    echo "<script> alert {'Data tidak berhasil diupdate'} </script>";
    header ("refresh:0;adminhotel.php");
}
?>