<?php
include "function.php";

$hotel_id = $_GET['hotel_id'];

$hapus = mysqli_query($conn, "DELETE FROM avail_hotel WHERE hotel_id = '$hotel_id'");

if ($hapus){
    echo "<script> alert {'Data berhasil dihapus'} </script>";
    header ("refresh:0;adminhotel.php");
} else {
    echo "<script> alert {'Data tidak berhasil dihapus'} </script>";
    header ("refresh:0;adminhotel.php");
}
?>