<?php

//Koneksi ke database
$conn = mysqli_connect("localhost","root","","gonation");

?>