<html>
<head>
        <title>Update Kereta</title>
</head>
<body>
    <h3 align="center"> Form Ubah Data</h3>
    <?php
    include "function.php";

    $train_id = $_GET['train_id'];
    $data = mysqli_query($conn, "SELECT * FROM avail_train WHERE train_id = '$train_id'");
    while ($tampil = mysqli_fetch_array($data)){
        ?>

    <form action="ubahkereta.php" method="post">
    <table align="center" bgcolor="green" width="60%">
        <tr>
            <td>ID Kereta:</td>
            <td>
                <input type="text" name="id" size="30" value="<?php echo $tampil['train_id'];?>" readonly>
            </td>
            </tr>
        <tr>
        <td>ID Class:</td>
            <td>
                <input type="text" name="class" size="30" value="<?php echo $tampil['class_id'];?>">
            </td>
    </tr>
    <tr>
        <td>Stasiun Keberangkatan:</td>
            <td>
                <input type="text" name="tglberangkat" size="30" value="<?php echo $tampil['train_departure'];?>">
            </td>
    </tr>
    <tr>
        <td>Stasiun Tiba:</td>
            <td>
                <input type="text" name="tgltiba" size="30" value="<?php echo $tampil['train_arrival'];?>">
            </td>
    </tr>
    <tr>
        <td>Jumlah Kursi:</td>
            <td>
                <input type="text" name="kursi" size="30" value="<?php echo $tampil['train_seats'];?>">
            </td>
    </tr>
    <tr>
        <td>Tanggal Tiba:</td>
            <td>
                <input type="text" name="harga" size="30" value="<?php echo $tampil['train_price'];?>">
            </td>
    </tr>
    <tr>
        <td></td>
        <td></td>
        <td>
            <input type="submit" name="simpan" value="Simpan">
    </td>
    </tr>
    </table>
    </form>
    <?php
    }
    ?>
</body>
</html>