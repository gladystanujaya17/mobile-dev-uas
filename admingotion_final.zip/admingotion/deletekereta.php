<?php
include "function.php";

$train_id = $_GET['train_id'];

$hapus = mysqli_query($conn, "DELETE FROM avail_train WHERE train_id = '$train_id'");

if ($hapus){
    echo "<script> alert {'Data berhasil dihapus'} </script>";
    header ("refresh:0;admin.php");
} else {
    echo "<script> alert {'Data tidak berhasil dihapus'} </script>";
    header ("refresh:0;admin.php");
}
?>