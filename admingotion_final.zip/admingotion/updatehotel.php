
<html>
<head>
        <title>Update Hotel</title>
</head>
<body>
    <h3 align="center"> Form Ubah Data</h3>
    <?php
    include "function.php";

    $hotel_id = $_GET['hotel_id'];
    $data = mysqli_query($conn, "SELECT * FROM avail_hotel WHERE hotel_id = '$hotel_id'");
    while ($tampil = mysqli_fetch_array($data)){
        ?>

    <form action="ubahhotel.php" method="post">
    <table align="center" bgcolor="green" width="60%">
        <tr>
            <td>ID Hotel:</td>
            <td>
                <input type="text" name="id" size="30" value="<?php echo $tampil['hotel_id'];?>" readonly>
            </td>
            </tr>
        <tr>
        <td>Tanggal Masuk:</td>
            <td>
                <input type="text" name="tglmasuk" size="30" value="<?php echo $tampil['tanggal_masuk'];?>">
            </td>
    </tr>
    <tr>
        <td>Tanggal Keluar:</td>
            <td>
                <input type="text" name="tglkeluar" size="30" value="<?php echo $tampil['tanggal_keluar'];?>">
            </td>
    </tr>
    <tr>
        <td>Harga:</td>
            <td>
                <input type="text" name="harga" size="30" value="<?php echo $tampil['harga'];?>">
            </td>
    </tr>
    <tr>
        <td></td>
        <td></td>
        <td>
            <input type="submit" name="simpan" value="Simpan">
    </td>
    </tr>
    </table>
    </form>
    <?php
    }
    ?>
</body>
</html>